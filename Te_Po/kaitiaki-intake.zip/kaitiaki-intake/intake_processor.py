#!/usr/bin/env python3
"""
Kaitiaki Content Intake Processor
Converts various formats to kaitiaki-readable content with cultural intelligence
"""

import os
import json
import subprocess
import hashlib
from pathlib import Path
from datetime import datetime
import mimetypes
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class KaitiakiIntake:
    def __init__(self, base_path=None):
        self.base_path = Path(base_path) if base_path else Path(__file__).parent
        self.raw_dir = self.base_path / "raw"
        self.processed_dir = self.base_path / "processed" 
        self.active_dir = self.base_path / "active"
        
        # Supported conversions
        self.converters = {
            'text/html': self.convert_html,
            'application/pdf': self.convert_pdf,
            'text/plain': self.convert_text,
            'application/json': self.convert_json,
            'text/markdown': self.convert_markdown,
            'application/msword': self.convert_doc,
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': self.convert_docx
        }

    def get_file_hash(self, filepath):
        """Generate hash for duplicate detection"""
        with open(filepath, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()

    def detect_cultural_context(self, content):
        """Detect cultural context in content using keywords"""
        cultural_indicators = {
            'tikanga': ['tikanga', 'māori', 'iwi', 'hapū', 'whānau', 'mauri', 'taonga', 'whakapapa'],
            'sovereignty': ['sovereignty', 'tino rangatiratanga', 'self-determination', 'governance'],
            'data': ['data', 'information', 'knowledge', 'mātauranga'],
            'protocol': ['protocol', 'kawa', 'ceremony', 'karakia', 'pōwhiri'],
            'environment': ['environment', 'whenua', 'moana', 'taiao', 'sustainability'],
            'community': ['community', 'collective', 'whakakotahitanga', 'kotahitanga']
        }
        
        detected_contexts = []
        content_lower = content.lower()
        
        for context, keywords in cultural_indicators.items():
            if any(keyword in content_lower for keyword in keywords):
                detected_contexts.append(context)
        
        return detected_contexts

    def convert_html(self, filepath):
        """Convert HTML to clean markdown using pandoc"""
        try:
            output_path = self.processed_dir / f"{filepath.stem}.md"
            result = subprocess.run([
                'pandoc', str(filepath), '-o', str(output_path),
                '--from=html', '--to=markdown',
                '--wrap=preserve', '--extract-media=.'
            ], capture_output=True, text=True, check=True)
            
            logger.info(f"✅ Converted HTML: {filepath.name} → {output_path.name}")
            return output_path
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ HTML conversion failed: {e}")
            return None

    def convert_pdf(self, filepath):
        """Convert PDF to text (requires pdftotext)"""
        try:
            output_path = self.processed_dir / f"{filepath.stem}.md"
            # Try pdftotext first, fallback to pandoc
            try:
                result = subprocess.run([
                    'pdftotext', str(filepath), '-'
                ], capture_output=True, text=True, check=True)
                content = result.stdout
            except (subprocess.CalledProcessError, FileNotFoundError):
                # Fallback to pandoc
                result = subprocess.run([
                    'pandoc', str(filepath), '-o', str(output_path),
                    '--from=pdf', '--to=markdown'
                ], capture_output=True, text=True, check=True)
                return output_path
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(f"# {filepath.stem}\n\n")
                f.write(content)
            
            logger.info(f"✅ Converted PDF: {filepath.name} → {output_path.name}")
            return output_path
        except Exception as e:
            logger.error(f"❌ PDF conversion failed: {e}")
            return None

    def convert_text(self, filepath):
        """Process plain text files"""
        output_path = self.processed_dir / f"{filepath.stem}.md"
        try:
            with open(filepath, 'r', encoding='utf-8') as infile:
                content = infile.read()
            
            with open(output_path, 'w', encoding='utf-8') as outfile:
                outfile.write(f"# {filepath.stem}\n\n")
                outfile.write(content)
            
            logger.info(f"✅ Processed text: {filepath.name} → {output_path.name}")
            return output_path
        except Exception as e:
            logger.error(f"❌ Text processing failed: {e}")
            return None

    def convert_json(self, filepath):
        """Convert JSON to readable markdown"""
        output_path = self.processed_dir / f"{filepath.stem}.md"
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(f"# {filepath.stem}\n\n")
                f.write("```json\n")
                f.write(json.dumps(data, indent=2, ensure_ascii=False))
                f.write("\n```\n")
            
            logger.info(f"✅ Converted JSON: {filepath.name} → {output_path.name}")
            return output_path
        except Exception as e:
            logger.error(f"❌ JSON conversion failed: {e}")
            return None

    def convert_markdown(self, filepath):
        """Copy markdown files (already in good format)"""
        output_path = self.processed_dir / filepath.name
        try:
            import shutil
            shutil.copy2(filepath, output_path)
            logger.info(f"✅ Copied markdown: {filepath.name}")
            return output_path
        except Exception as e:
            logger.error(f"❌ Markdown copy failed: {e}")
            return None

    def convert_doc(self, filepath):
        """Convert DOC files using pandoc"""
        return self.convert_with_pandoc(filepath, 'docx')

    def convert_docx(self, filepath):
        """Convert DOCX files using pandoc"""
        return self.convert_with_pandoc(filepath, 'docx')

    def convert_with_pandoc(self, filepath, from_format):
        """Generic pandoc converter"""
        try:
            output_path = self.processed_dir / f"{filepath.stem}.md"
            result = subprocess.run([
                'pandoc', str(filepath), '-o', str(output_path),
                f'--from={from_format}', '--to=markdown'
            ], capture_output=True, text=True, check=True)
            
            logger.info(f"✅ Converted {from_format}: {filepath.name} → {output_path.name}")
            return output_path
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ {from_format} conversion failed: {e}")
            return None

    def create_kaitiaki_manifest(self, original_file, processed_file, cultural_contexts):
        """Create manifest for kaitiaki processing"""
        manifest = {
            'timestamp': datetime.now().isoformat(),
            'original_file': str(original_file),
            'processed_file': str(processed_file),
            'file_hash': self.get_file_hash(original_file),
            'cultural_contexts': cultural_contexts,
            'mime_type': mimetypes.guess_type(str(original_file))[0],
            'recommended_kaitiaki': self.recommend_kaitiaki(cultural_contexts),
            'processing_status': 'ready_for_kaitiaki',
            'taonga_level': self.assess_taonga_level(cultural_contexts)
        }
        
        manifest_path = self.active_dir / f"{processed_file.stem}_manifest.json"
        with open(manifest_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)
        
        return manifest_path

    def recommend_kaitiaki(self, cultural_contexts):
        """Recommend which kaitiaki should process this content"""
        recommendations = []
        
        if 'sovereignty' in cultural_contexts:
            recommendations.extend(['whiro', 'ranginui'])  # Validator, Oversight
        if 'tikanga' in cultural_contexts:
            recommendations.extend(['rongohia', 'te_rongo'])  # Carver, Harmony
        if 'data' in cultural_contexts:
            recommendations.extend(['mataroa', 'hinewai'])  # Navigator, Purifier
        if 'protocol' in cultural_contexts:
            recommendations.extend(['whiro', 'kitenga'])  # Validator, Coordinator
        if 'community' in cultural_contexts:
            recommendations.extend(['aotahi', 'rongokarere'])  # Collective, Messenger
        
        # Always include Mataroa for navigation
        if 'mataroa' not in recommendations:
            recommendations.append('mataroa')
        
        return list(set(recommendations))  # Remove duplicates

    def assess_taonga_level(self, cultural_contexts):
        """Assess how culturally significant this content is"""
        if len(cultural_contexts) >= 3:
            return 'high_taonga'  # Multiple cultural contexts = sacred
        elif any(context in ['tikanga', 'sovereignty'] for context in cultural_contexts):
            return 'medium_taonga'  # Core cultural concepts
        elif cultural_contexts:
            return 'low_taonga'  # Some cultural relevance
        else:
            return 'general'  # General content

    def process_file(self, filepath):
        """Process a single file through the intake system"""
        logger.info(f"🔄 Processing: {filepath.name}")
        
        # Detect mime type
        mime_type, _ = mimetypes.guess_type(str(filepath))
        if not mime_type:
            logger.warning(f"⚠️ Unknown file type: {filepath.name}")
            return None
        
        # Convert using appropriate converter
        converter = self.converters.get(mime_type)
        if not converter:
            logger.warning(f"⚠️ No converter for {mime_type}: {filepath.name}")
            return None
        
        processed_file = converter(filepath)
        if not processed_file:
            return None
        
        # Analyze cultural context
        try:
            with open(processed_file, 'r', encoding='utf-8') as f:
                content = f.read()
            cultural_contexts = self.detect_cultural_context(content)
        except Exception:
            cultural_contexts = []
        
        # Create kaitiaki manifest
        manifest_path = self.create_kaitiaki_manifest(filepath, processed_file, cultural_contexts)
        
        # Move processed file to active directory
        active_file = self.active_dir / processed_file.name
        processed_file.rename(active_file)
        
        logger.info(f"✅ Ready for kaitiaki: {active_file.name}")
        logger.info(f"📋 Cultural contexts: {cultural_contexts}")
        logger.info(f"🤖 Recommended kaitiaki: {json.load(open(manifest_path))['recommended_kaitiaki']}")
        
        return {
            'active_file': active_file,
            'manifest': manifest_path,
            'cultural_contexts': cultural_contexts
        }

    def process_raw_directory(self):
        """Process all files in the raw directory"""
        logger.info("🚀 Starting kaitiaki intake processing...")
        
        processed_count = 0
        for file_path in self.raw_dir.iterdir():
            if file_path.is_file():
                result = self.process_file(file_path)
                if result:
                    processed_count += 1
                    # Move processed raw file to archive
                    archive_dir = self.base_path / "raw_archive"
                    archive_dir.mkdir(exist_ok=True)
                    file_path.rename(archive_dir / file_path.name)
        
        logger.info(f"🎯 Processed {processed_count} files for kaitiaki")
        return processed_count

def main():
    intake = KaitiakiIntake()
    
    # Check for pandoc
    try:
        subprocess.run(['pandoc', '--version'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        logger.error("❌ Pandoc not found. Install with: sudo apt install pandoc")
        return
    
    print("🌺 Kaitiaki Content Intake Processor")
    print("📂 Drop files in 'raw/' directory and run this script")
    print("🤖 Files will be converted and prepared for kaitiaki processing\n")
    
    # Process any files in raw directory
    count = intake.process_raw_directory()
    
    if count == 0:
        print("📝 No files found in raw/ directory")
        print("💡 Drop your files (HTML, PDF, DOC, etc.) in 'raw/' then run again")

if __name__ == "__main__":
    main()