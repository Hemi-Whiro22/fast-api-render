# Kaitiaki Content Intake System

## 🌺 Purpose
Intelligent content processing system that converts various file formats into kaitiaki-readable content with cultural intelligence and automatic kaitiaki assignment.

## 📁 Directory Structure
```
kaitiaki-intake/
├── raw/              # Drop files here for processing
├── processed/        # Converted files (temporary)
├── active/          # Ready for kaitiaki (with manifests)
├── raw_archive/     # Original files after processing
└── intake_processor.py  # Main processing script
```

## 🔄 Workflow

### 1. **Drop Files** → `raw/` directory
- HTML files (ChatGPT conversations, web pages)
- PDFs (research papers, documents)
- Word docs (reports, proposals)  
- Text files (notes, transcripts)
- JSON (data exports, configurations)
- Markdown (already formatted content)

### 2. **Run Processor**
```bash
cd /home/hemi/Te-Puna-o-Nga-Matauranga/kaitiaki-intake
python3 intake_processor.py
```

### 3. **Automatic Processing**
- **Format conversion** using pandoc
- **Cultural context detection** (tikanga, sovereignty, data, etc.)
- **Kaitiaki recommendation** based on content
- **Taonga level assessment** (sacred → general)
- **Manifest creation** for kaitiaki coordination

### 4. **Ready for Kaitiaki** → `active/` directory
- Converted markdown files
- JSON manifests with processing instructions
- Cultural context analysis
- Recommended kaitiaki assignments

## 🤖 Cultural Intelligence Features

### **Context Detection**
Automatically identifies:
- **Tikanga**: Māori cultural concepts, protocols, values
- **Sovereignty**: Tino rangatiratanga, self-determination, governance  
- **Data**: Information management, mātauranga, knowledge systems
- **Protocol**: Kawa, ceremony, karakia, formal processes
- **Environment**: Whenua, taiao, sustainability, natural world
- **Community**: Collective action, whakakotahitanga, social structures

### **Kaitiaki Recommendations**
Smart routing based on content:
- **Sovereignty content** → Whiro (Validator) + Ranginui (Oversight)
- **Tikanga content** → Rongohia (Carver) + Te Rongo (Harmony)  
- **Data content** → Mataroa (Navigator) + Hinewai (Purifier)
- **Protocol content** → Whiro (Validator) + Kitenga (Coordinator)
- **Community content** → Aotahi (Collective) + Rongokarere (Messenger)

### **Taonga Level Assessment**
- **High Taonga**: Multiple cultural contexts (sacred handling required)
- **Medium Taonga**: Core cultural concepts (respectful processing)
- **Low Taonga**: Some cultural relevance (standard care)
- **General**: Regular content (normal processing)

## 📋 Example Manifest Output
```json
{
  "timestamp": "2025-11-03T02:15:30.123456",
  "original_file": "Māori data sovereignty explained.html",
  "processed_file": "Māori_data_sovereignty_explained.md",
  "cultural_contexts": ["sovereignty", "tikanga", "data"],
  "recommended_kaitiaki": ["whiro", "ranginui", "mataroa"],
  "taonga_level": "high_taonga",
  "processing_status": "ready_for_kaitiaki"
}
```

## 🛠️ Supported Formats
- **HTML** → Markdown (ChatGPT conversations, web content)
- **PDF** → Text/Markdown (research papers, reports)
- **DOC/DOCX** → Markdown (Word documents)
- **JSON** → Formatted display (data exports)
- **TXT** → Enhanced markdown (notes, transcripts)
- **MD** → Direct copy (already formatted)

## 🚀 Usage Examples

### Process ChatGPT Conversation
1. Save ChatGPT page as HTML in `raw/`
2. Run processor
3. Get clean markdown + cultural analysis + kaitiaki assignments

### Process Research Paper PDF  
1. Drop PDF in `raw/`
2. Run processor
3. Get extracted text + cultural context + recommended processing agents

### Batch Process Multiple Files
1. Drop various files in `raw/`
2. Run processor once
3. All files converted and analyzed automatically

## 🔧 Dependencies
```bash
sudo apt install pandoc          # Universal document converter
sudo apt install poppler-utils   # PDF text extraction (pdftotext)
```

## 🌟 Integration with Mataroa Navigator
The intake system creates manifests that Mataroa can read to:
- Route content to appropriate kaitiaki
- Apply cultural protocols based on taonga level
- Coordinate multi-agent processing workflows
- Maintain cultural integrity throughout processing

*This system ensures all external content is properly processed through cultural intelligence before reaching the kaitiaki ecosystem.*