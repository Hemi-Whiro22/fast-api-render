# test_iwi_data

```json
{
  "iwi_registry": {
    "name": "Te Iwi Matatū",
    "rohe": "Canterbury/Waitaha region",
    "established": "time immemorial",
    "governance": {
      "kaumātua": [
        {
          "name": "Nan Ripeka",
          "role": "senior_kuia",
          "expertise": [
            "whakapapa",
            "tikanga",
            "te_reo"
          ]
        },
        {
          "name": "Koro Tamati",
          "role": "senior_koroua",
          "expertise": [
            "whenua",
            "mahinga_kai",
            "whakapapa"
          ]
        }
      ],
      "committees": {
        "data_sovereignty": {
          "chair": "Dr. Aroha Williams",
          "members": 5,
          "established": "2023",
          "mandate": "Oversee all digital initiatives affecting iwi data"
        }
      }
    },
    "cultural_assets": {
      "taonga": [
        {
          "type": "whakapapa_records",
          "status": "tapu",
          "access_level": "restricted"
        },
        {
          "type": "oral_histories",
          "status": "taonga",
          "access_level": "community_only"
        },
        {
          "type": "mahinga_kai_locations",
          "status": "sensitive",
          "access_level": "iwi_members"
        }
      ],
      "intellectual_property": {
        "traditional_knowledge": "collectively_owned",
        "stories": "whakapapa_based_access",
        "place_names": "public_with_attribution"
      }
    },
    "digital_protocols": {
      "data_storage": "on_iwi_servers_preferred",
      "external_sharing": "requires_committee_approval",
      "research_access": "community_benefit_required",
      "commercial_use": "strictly_prohibited"
    }
  }
}
```
