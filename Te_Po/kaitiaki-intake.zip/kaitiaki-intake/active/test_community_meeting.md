# test_community_meeting

Community Meeting Minutes - October 2025
Environmental Protection Hui

Attendees: 24 iwi members, 3 council representatives, 2 environmental scientists

AGENDA ITEMS:

1. River Health Assessment
   - Water quality testing results concerning
   - Traditional mahinga kai sites under threat
   - Need for coordinated response

2. Climate Change Adaptation
   - Traditional knowledge about weather patterns
   - Combining mātauranga Māori with western science
   - Community resilience planning

3. Data Sharing Protocols
   - Research partnerships with university
   - Ensuring community benefits from any studies
   - Protecting sensitive location information

4. Youth Engagement
   - Connecting rangatahi to environmental work
   - Digital tools for knowledge sharing
   - Balancing innovation with tradition

ACTION ITEMS:
- Set up working group for water quality monitoring
- Develop community protocols for research partnerships
- Create youth-led environmental monitoring project
- Establish digital platform for knowledge sharing

CULTURAL CONSIDERATIONS:
- All activities must follow tikanga protocols
- Kaumātua guidance required for sensitive sites
- Community ownership of all data collected
- Environmental work seen as kaitiakitanga responsibility

Next meeting: November 15, 2025 at marae