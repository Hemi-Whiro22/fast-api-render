#!/usr/bin/env python3
"""
Kaitiaki Intake Web Server
Handles file uploads from the web UI and processes them through the intake system
"""

import os
import json
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from aiohttp import web, MultipartReader
from aiohttp.web_fileresponse import FileResponse
import aiofiles
import uuid

# Import our intake processor
from intake_processor import KaitiakiIntake

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class KaitiakiWebServer:
    def __init__(self, port=8080):
        self.port = port
        self.intake = KaitiakiIntake()
        self.app = web.Application()
        self.setup_routes()
        
    def setup_routes(self):
        """Setup web server routes"""
        self.app.router.add_get('/', self.serve_portal)
        self.app.router.add_post('/upload', self.handle_upload)
        self.app.router.add_get('/status/{file_id}', self.get_status)
        self.app.router.add_get('/queue', self.get_queue_status)
        
    async def serve_portal(self, request):
        """Serve the main intake portal HTML"""
        portal_path = Path(__file__).parent / 'intake_portal.html'
        return FileResponse(portal_path)
        
    async def handle_upload(self, request):
        """Handle file upload from the web interface"""
        try:
            reader = await request.multipart()
            uploaded_files = []
            
            async for field in reader:
                if field.name == 'file' and field.filename:
                    # Generate unique filename to avoid conflicts
                    file_id = str(uuid.uuid4())[:8]
                    safe_filename = f"{file_id}_{field.filename}"
                    file_path = self.intake.raw_dir / safe_filename
                    
                    # Save uploaded file
                    async with aiofiles.open(file_path, 'wb') as f:
                        async for chunk in field.iter_chunked(8192):
                            await f.write(chunk)
                    
                    logger.info(f"📁 Uploaded: {field.filename} → {safe_filename}")
                    
                    # Process file asynchronously
                    asyncio.create_task(self.process_file_async(file_path, file_id, field.filename))
                    
                    uploaded_files.append({
                        'file_id': file_id,
                        'original_name': field.filename,
                        'status': 'processing'
                    })
            
            return web.json_response({
                'success': True,
                'files': uploaded_files,
                'message': f'Uploaded {len(uploaded_files)} file(s) for processing'
            })
            
        except Exception as e:
            logger.error(f"❌ Upload error: {e}")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def process_file_async(self, file_path, file_id, original_name):
        """Process uploaded file asynchronously"""
        try:
            logger.info(f"🔄 Processing: {original_name}")
            
            # Run the intake processor
            result = await asyncio.get_event_loop().run_in_executor(
                None, self.intake.process_file, file_path
            )
            
            if result:
                # Store processing result for status queries
                result_data = {
                    'file_id': file_id,
                    'original_name': original_name,
                    'status': 'complete',
                    'processed_at': datetime.now().isoformat(),
                    'cultural_contexts': result.get('cultural_contexts', []),
                    'manifest_path': str(result.get('manifest')),
                    'active_file': str(result.get('active_file'))
                }
                
                # Save result to status file
                status_file = self.intake.base_path / f"status_{file_id}.json"
                async with aiofiles.open(status_file, 'w') as f:
                    await f.write(json.dumps(result_data, indent=2))
                
                logger.info(f"✅ Completed: {original_name}")
            else:
                logger.error(f"❌ Failed to process: {original_name}")
                
        except Exception as e:
            logger.error(f"❌ Processing error for {original_name}: {e}")
    
    async def get_status(self, request):
        """Get processing status for a specific file"""
        file_id = request.match_info['file_id']
        status_file = self.intake.base_path / f"status_{file_id}.json"
        
        try:
            if status_file.exists():
                async with aiofiles.open(status_file, 'r') as f:
                    status_data = json.loads(await f.read())
                return web.json_response(status_data)
            else:
                return web.json_response({
                    'file_id': file_id,
                    'status': 'processing'
                })
        except Exception as e:
            return web.json_response({
                'error': str(e)
            }, status=500)
    
    async def get_queue_status(self, request):
        """Get overall queue status"""
        try:
            # Count files in different stages
            raw_count = len(list(self.intake.raw_dir.glob('*'))) if self.intake.raw_dir.exists() else 0
            active_count = len(list(self.intake.active_dir.glob('*.md'))) if self.intake.active_dir.exists() else 0
            
            # Get recent status files
            status_files = list(self.intake.base_path.glob('status_*.json'))
            recent_files = []
            
            for status_file in sorted(status_files, key=lambda f: f.stat().st_mtime, reverse=True)[:10]:
                try:
                    async with aiofiles.open(status_file, 'r') as f:
                        file_data = json.loads(await f.read())
                        recent_files.append(file_data)
                except Exception:
                    continue
            
            return web.json_response({
                'queue_stats': {
                    'raw_files': raw_count,
                    'active_files': active_count,
                    'total_processed': len(status_files)
                },
                'recent_files': recent_files
            })
            
        except Exception as e:
            return web.json_response({
                'error': str(e)
            }, status=500)
    
    def run(self):
        """Start the web server"""
        print(f"\n🌺 Kaitiaki Intake Portal")
        print(f"🌐 Server starting on http://localhost:{self.port}")
        print(f"📂 Raw files: {self.intake.raw_dir}")
        print(f"📋 Active files: {self.intake.active_dir}")
        print(f"\n💡 Open http://localhost:{self.port} in your browser")
        print(f"📥 Drag & drop files to process with cultural intelligence\n")
        
        web.run_app(self.app, host='localhost', port=self.port)

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Kaitiaki Intake Web Server')
    parser.add_argument('--port', type=int, default=8080, help='Server port (default: 8080)')
    args = parser.parse_args()
    
    # Check dependencies
    try:
        import aiohttp
        import aiofiles
    except ImportError:
        print("❌ Missing dependencies. Install with:")
        print("   pip install aiohttp aiofiles")
        return
    
    server = KaitiakiWebServer(port=args.port)
    server.run()

if __name__ == "__main__":
    main()