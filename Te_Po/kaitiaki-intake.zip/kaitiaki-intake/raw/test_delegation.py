#!/usr/bin/env python3
"""
Test Mataroa → Rongohia delegation
"""

import sys
import os
sys.path.append('/home/hemi/Te-Puna-o-Nga-Matauranga')

from pathlib import Path
from mataroa_navigator import Mataroa

def test_delegation():
    print("🧪 Testing Mataroa → Rongohia delegation")
    
    # Initialize Mataroa
    kitenga_path = Path("/home/hemi/Te-Puna-o-Nga-Matauranga/Kitenga")
    mataroa = Mataroa(kitenga_path)
    
    # Test delegation to Rongohia
    task_data = {
        "source": "kitenga-home",
        "files_available": {
            "kaitiaki": 2,
            "strategy": 1,
            "whakapapa": 1
        },
        "request": "carve_cultural_dashboard"
    }
    
    result = mataroa.delegate_to_kaitiaki("rongohia", task_data)
    print(f"📋 Delegation result: {result}")
    
    # Test Mirrora sync
    sync_result = mataroa.sync_with_mirrora()
    print(f"☁️ Mirrora sync hash: {sync_result['registry_hash']}")

if __name__ == "__main__":
    test_delegation()